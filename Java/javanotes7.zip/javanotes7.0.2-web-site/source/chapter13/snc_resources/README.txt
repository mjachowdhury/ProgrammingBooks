The files in this directory are resources for
the sample program SoundAndCursorDemo.